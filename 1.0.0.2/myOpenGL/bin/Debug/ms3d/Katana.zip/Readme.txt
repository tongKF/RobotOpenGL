This model may be used with accepted freeware license agreement that you not sell it. You may distribute it with your projects (either commercial or otherwise), with credit given to me. Either a TogaMario or Tyler Drinkard in the credits will do :P

Feel free to modify the model and texture to suit your needs.

Thanks, and enjoy.
-Tyler Drinkard

TogaMario@aol.com
www.togamario.com
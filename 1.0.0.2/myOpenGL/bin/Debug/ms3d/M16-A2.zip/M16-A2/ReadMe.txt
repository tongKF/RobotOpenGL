/////////////////////////////////////////////////////
Copyright 2005 RedCore Software and Design
/////////////////////////////////////////////////////

Hi,

Thanks for downloading this model, i sure hope that you like it and it suits your standards, please do not distribute this model without permission from me, Jonathan Fletcher.

If you would like to contact me for suggestions, feedback, for other reasons, please email:

jonfletc@gmail.com